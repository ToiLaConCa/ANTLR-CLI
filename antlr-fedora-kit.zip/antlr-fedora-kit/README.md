# ANTLR 4.13.2 Kit cho Fedora (Java + C++)

Chuyển guide `Userguide_ANTLR_C++.docx` (Windows) + slide `Tokens/grun` sang Fedora.
Cài một lệnh, có sẵn 3 ví dụ chạy ra đúng kết quả trong guide/slide.

## Cấu trúc

```
antlr-fedora-kit/
├── install.sh            # cài toàn bộ (dnf + jar + runtime C++ + lệnh antlr4/grun + env)
├── test.sh               # chạy thử 3 ví dụ, tự kiểm tra kết quả
├── ROADMAP.md            # các bước cài theo thứ tự
├── jar/                  # antlr-4.13.2-complete.jar (file bạn gửi)
├── runtime-cpp/          # source C++ runtime 4.13.2 chính thức (thay cho antlr4-dev trong software.zip)
├── bin/                  # antlr4, grun  (thay cho grun.bat)
└── examples/
    ├── tokens/           # slide: Tokens.g4 + grun -tokens
    ├── calculator/       # guide: Calculator.g4 + main.cpp (parse tree)
    └── identifier/       # guide: CIdentifier.g4 + main.cpp (Example 1)
```

## Windows → Fedora: cái gì thay bằng cái gì

| Guide Windows                         | Trên Fedora                                              |
|---------------------------------------|----------------------------------------------------------|
| MinGW-w64 + biến môi trường           | `g++` (gói `gcc-c++`), không cần cấu hình PATH           |
| CMake 3.31.6 (software.zip)           | `cmake` từ dnf                                           |
| JDK tải từ Oracle                     | `java-latest-openjdk-devel` từ dnf                       |
| `ANTLR_HOME`, `CLASSPATH` (sysdm.cpl) | `~/.config/antlr/env.sh` / `env.fish` (install.sh tạo)   |
| `antlr4-dev` trong software.zip       | `runtime-cpp/` trong gói, build ra `~/antlr/antlr4-dev`  |
| `libantlr4-runtime.dll`               | `libantlr4-runtime.so` (dùng `-Wl,-rpath`, khỏi copy)    |
| `grun.bat` (đặt trong `C:\Windows`)   | `~/.local/bin/grun`                                      |
| `mingw32-make`, `-G "MinGW Makefiles"`| `make` mặc định                                          |
| Kết thúc input bằng `Ctrl+Z`          | `Ctrl+D`                                                 |

## Guide còn thiếu / sai chỗ nào (đã bổ sung trong kit)

1. **`software.zip` không có trong file bạn up** (MinGW, CMake, `antlr4-dev`). Kit lấy runtime C++ từ bản source chính thức 4.13.2 nên không cần file đó.
2. **Thiếu cờ `-visitor`** ở bước 7: guide liệt kê `CalculatorBaseVisitor.*` nhưng lệnh `java -jar ... -Dlanguage=Cpp Calculator.g4` không sinh ra file đó. `calculator/build.sh` đã thêm `-visitor`.
3. **Thiếu `-std=c++17`** khi biên dịch (runtime 4.13 yêu cầu C++17).
4. **Cần build runtime với `-DANTLR_BUILD_CPP_TESTS=OFF`**, nếu không CMake đòi tải gtest từ mạng. `install.sh` đã tắt.
5. **Đường dẫn lộn xộn**: guide viết lẫn `F:\ANTLR\project`, `F:\ANTLR\projects`, `D:\ANTLR`. Trên Linux mọi thứ nằm dưới `~/antlr`.
6. **Example 1 đề nói Pascal identifier** (bắt đầu bằng chữ thường, tiếp theo chữ thường hoặc số) nhưng grammar trong guide là kiểu C (`[a-zA-Z_][a-zA-Z0-9_]*`). Nếu bài nộp theo đề Pascal, đổi dòng trong `CIdentifier.g4` thành:
   ```
   IDENTIFIER: [a-z][a-z0-9]* ;
   ```
7. Slide `Tokens`: kết quả của bạn có EOF ở `7:6` vì Windows xuống dòng bằng `\r\n`; trên Linux là `6:5`. Các token còn lại giống hệt.

## Đã test chưa?

`install.sh` + `test.sh` đã chạy thành công (6/6 kiểm tra đạt) trên Ubuntu 24.04 với g++, CMake 4.x, OpenJDK 21. Chưa chạy trực tiếp trên máy Fedora của bạn. Các lệnh dnf (`java-latest-openjdk-devel gcc-c++ cmake make git`) là tên gói chuẩn của Fedora. Nếu có lỗi, xem bảng xử lý lỗi cuối `ROADMAP.md`.

## Gỡ cài đặt

```bash
rm -rf ~/antlr ~/.config/antlr ~/.local/bin/antlr4 ~/.local/bin/grun
# rồi xoá dòng "source .../antlr/env.*" trong ~/.bashrc và ~/.config/fish/config.fish
```
