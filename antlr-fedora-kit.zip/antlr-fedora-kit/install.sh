#!/usr/bin/env bash
# ANTLR 4.13.2 (Java + C++ runtime) installer cho Fedora.
# Tuong duong Buoc 1-5 cua guide Windows (MinGW/CMake/JDK/ANTLR jar/runtime C++).
#
# Dung:   ./install.sh              # cai day du (can sudo cho dnf)
#         ./install.sh --skip-deps  # bo qua dnf (neu da cai goi roi)
set -euo pipefail

KIT="$(cd "$(dirname "$0")" && pwd)"
ANTLR_HOME="${ANTLR_HOME:-$HOME/antlr}"
DEV="$ANTLR_HOME/antlr4-dev"
JAR_NAME="antlr-4.13.2-complete.jar"
SKIP_DEPS=0
[[ "${1:-}" == "--skip-deps" ]] && SKIP_DEPS=1

say() { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }

# ---------------------------------------------------------------
# 1. Goi he thong (thay cho MinGW + CMake + JDK tren Windows)
# ---------------------------------------------------------------
if [[ $SKIP_DEPS -eq 0 ]]; then
  say "Cai goi bang dnf: JDK, g++, cmake, make, git"
  sudo dnf install -y java-latest-openjdk-devel gcc-c++ cmake make git
else
  say "Bo qua dnf (--skip-deps)"
fi

for cmd in java javac g++ cmake make; do
  command -v "$cmd" >/dev/null || { echo "THIEU: $cmd (chay lai khong co --skip-deps)"; exit 1; }
done

# ---------------------------------------------------------------
# 2. Copy ANTLR jar  (thay cho D:\ANTLR\antlr-4.13.2-complete.jar)
# ---------------------------------------------------------------
say "Cai ANTLR jar vao $ANTLR_HOME"
mkdir -p "$ANTLR_HOME"
cp -f "$KIT/jar/$JAR_NAME" "$ANTLR_HOME/$JAR_NAME"

# ---------------------------------------------------------------
# 3. Build + install C++ runtime  (thay cho cmake -G "MinGW Makefiles")
# ---------------------------------------------------------------
say "Build C++ runtime (mat vai phut)"
BUILD_DIR="$(mktemp -d)"
cmake -S "$KIT/runtime-cpp" -B "$BUILD_DIR" \
      -DCMAKE_BUILD_TYPE=Release \
      -DCMAKE_INSTALL_PREFIX="$DEV" \
      -DANTLR_BUILD_CPP_TESTS=OFF \
      -DDISABLE_WARNINGS=ON
cmake --build "$BUILD_DIR" -j"$(nproc)"
cmake --install "$BUILD_DIR"
rm -rf "$BUILD_DIR"

# ---------------------------------------------------------------
# 4. Lenh antlr4 / grun  (thay cho grun.bat)
# ---------------------------------------------------------------
say "Cai lenh antlr4, grun vao ~/.local/bin"
mkdir -p "$HOME/.local/bin"
install -m 755 "$KIT/bin/antlr4" "$HOME/.local/bin/antlr4"
install -m 755 "$KIT/bin/grun"   "$HOME/.local/bin/grun"

# ---------------------------------------------------------------
# 5. Bien moi truong  (thay cho ANTLR_HOME + CLASSPATH tren Windows)
# ---------------------------------------------------------------
say "Ghi bien moi truong"
mkdir -p "$HOME/.config/antlr"

cat > "$HOME/.config/antlr/env.sh" <<EOF
# ANTLR env (bash/zsh)
export ANTLR_HOME="$ANTLR_HOME"
export CLASSPATH=".:\$ANTLR_HOME/$JAR_NAME:\${CLASSPATH:-}"
export PATH="\$HOME/.local/bin:\$PATH"
export CPLUS_INCLUDE_PATH="$DEV/include/antlr4-runtime:\${CPLUS_INCLUDE_PATH:-}"
export LIBRARY_PATH="$DEV/lib:\${LIBRARY_PATH:-}"
export LD_LIBRARY_PATH="$DEV/lib:\${LD_LIBRARY_PATH:-}"
EOF

cat > "$HOME/.config/antlr/env.fish" <<EOF
# ANTLR env (fish)
set -gx ANTLR_HOME "$ANTLR_HOME"
set -gx CLASSPATH ".:\$ANTLR_HOME/$JAR_NAME"
fish_add_path \$HOME/.local/bin
set -gx CPLUS_INCLUDE_PATH "$DEV/include/antlr4-runtime"
set -gx LIBRARY_PATH "$DEV/lib"
set -gx LD_LIBRARY_PATH "$DEV/lib"
EOF

add_line() { # add_line <file> <line>
  mkdir -p "$(dirname "$1")"; touch "$1"
  grep -qxF "$2" "$1" || echo "$2" >> "$1"
}
add_line "$HOME/.bashrc" 'source "$HOME/.config/antlr/env.sh"'
[[ -f "$HOME/.zshrc" ]] && add_line "$HOME/.zshrc" 'source "$HOME/.config/antlr/env.sh"'
if command -v fish >/dev/null || [[ -d "$HOME/.config/fish" ]]; then
  add_line "$HOME/.config/fish/config.fish" 'source "$HOME/.config/antlr/env.fish"'
fi

say "XONG"
cat <<EOF

ANTLR_HOME  = $ANTLR_HOME
Runtime C++ = $DEV   (include/ + lib/)

Mo terminal MOI (hoac: source ~/.config/antlr/env.sh) roi chay:
  antlr4            # in ra "ANTLR Parser Generator Version 4.13.2"
  ./test.sh         # chay thu 3 vi du
EOF
